
import numpy as np
import polars as pl
from .logic import calculate_daily_ranges, backtest_core
from .indicators import calculate_adx, calculate_rsi, calculate_atr

class FastBacktester:
    def __init__(self, m1_data: pl.DataFrame):
        self.data = m1_data
        
        # Convert arrays
        self.times = self.data['time'].cast(pl.Int64).to_numpy() # Milliseconds
        self.opens = self.data['open'].to_numpy()
        self.highs = self.data['high'].to_numpy()
        self.lows = self.data['low'].to_numpy()
        self.closes = self.data['close'].to_numpy()
        
        if 'spread_est' in self.data.columns:
            self.spreads = self.data['spread_est'].fill_null(1.0).to_numpy()
        else:
            self.spreads = np.ones(len(self.data)) * 1.0
            
        self.ids = np.arange(len(self.data))
        
        # --- Pre-Calculate Indicators ---
        print("[Backtester] Pre-calculating Indicators (ADX 14, RSI 14, ATR 14)...")
        try:
            self.adx_14 = calculate_adx(self.highs, self.lows, self.closes, 14)
            self.rsi_14 = calculate_rsi(self.closes, 14)
            self.atr_14 = calculate_atr(self.highs, self.lows, self.closes, 14)
        except Exception as e:
             # Fallback if indicator calc fails (should not happens with Numba)
             print(f"[Backtester] Warning: Indicator calc failed? {e}")
             n = len(self.closes)
             self.adx_14 = np.zeros(n)
             self.rsi_14 = np.zeros(n)
             self.atr_14 = np.zeros(n)
        
        print(f"[Backtester] Ready with {len(self.data)} bars")

    def run(self, params: dict):
        """
        Run backtest with extended params (Cost, Filters) synced with logic.py.
        Uses .get() with defaults matching URB original inputs.
        """
        # Parse Params gracefully
        try:
            range_highs, range_lows = calculate_daily_ranges(
                self.times, self.highs, self.lows,
                int(params.get('InpRangeStartHour', 12)), int(params.get('InpRangeStartMin', 0)),
                int(params.get('InpRangeEndHour', 16)), int(params.get('InpRangeEndMin', 0))
            )
            
            final_equity, wins, losses, equity_curve, sqn, r2 = backtest_core(
                self.ids, self.times, self.opens, self.highs, self.lows, self.closes,
                range_highs, range_lows, self.spreads,
                
                # Indicators
                self.atr_14,
                self.adx_14,
                self.rsi_14,
                
                # General Settings
                int(params.get('InpTradingStartHour', 10)), int(params.get('InpTradingStartMin', 0)),
                int(params.get('InpTradingEndHour', 20)), int(params.get('InpTradingEndMin', 0)),
                int(params.get('InpTradeDirection', 2)),
                
                # Entry
                float(params.get('InpBreakoutBuffer', 20.0)),
                float(params.get('InpMinDistance_In_Points', 100.0)),
                
                # Risk
                float(params.get('InpFixedLot', 0.1)),
                float(params.get('InpRiskPerTradePct', 1.0)),
                int(params.get('InpSlMethod', 0)),
                float(params.get('InpFixedSL_In_Points', 50.0)),
                int(params.get('InpAtrSlPeriod', 14)), 
                float(params.get('InpAtrSlMultiplier', 1.5)),
                float(params.get('InpRiskRewardRatio', 2.0)),
                
                # Trailing
                int(params.get('InpExitStrategyMode', 2)),
                float(params.get('InpBreakevenTriggerPoints', 30.0)),
                float(params.get('InpBreakevenOffsetPoints', 5.0)),
                float(params.get('InpTrailingStartPoints', 20.0)),
                float(params.get('InpTrailingStepPoints', 10.0)),
                float(params.get('InpAtrTrailingMultiplier', 1.0)),
                
                # Filters
                bool(params.get('InpUseAdx', False)),
                float(params.get('InpAdxThreshold', 25.0)),
                bool(params.get('InpUseRsi', False)),
                float(params.get('InpRsiUpper', 70.0)),
                float(params.get('InpRsiLower', 30.0)),
                
                # Costs
                float(params.get('Commission', 7.0)), 
                float(params.get('SwapLong', -0.1)),
                float(params.get('SwapShort', -0.1))
            )
            
            total_trades = wins + losses
            win_rate = (wins / total_trades) * 100 if total_trades > 0 else 0.0
            net_profit = final_equity - 100000.0
            
            return {
                'NetProfit': net_profit,
                'Trades': total_trades,
                'WinRate': win_rate,
                'SQN': sqn,
                'R2': r2,
                'Equity': final_equity
            }
        except Exception as e:
            # Catch backend crashes to report error
            raise Exception(f"Backtest Run Error: {e}")
