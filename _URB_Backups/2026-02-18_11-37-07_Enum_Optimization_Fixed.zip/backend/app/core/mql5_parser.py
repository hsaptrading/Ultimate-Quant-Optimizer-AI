import re
import os
from typing import Dict, List, Any

class MQL5Parser:
    """
    Analizador de Código MQL5.
    Extrae la configuración de variables 'input' y 'sinput' para generar
    la interfaz de usuario (UI) automáticamente.
    """
    
    def __init__(self, filepath: str):
        self.filepath = filepath
        self.raw_content = ""
        self.inputs = [] # Lista ordenada de inputs
        
    def read_file(self) -> bool:
        if not os.path.exists(self.filepath):
            return False
        with open(self.filepath, "r", encoding="utf-8", errors="ignore") as f:
            self.raw_content = f.read()
        return True

    def parse_enums(self) -> Dict[str, List[Dict[str, str]]]:
        """
        Escanea el archivo buscando definiciones de enum personalizadas:
        enum ENUM_RISK_TYPE {
            RISK_PERCENT, // % del Balance
            RISK_FIXED_LOTS, // Lotes Fijos
            RISK_FIXED_MONEY // $ Fijos por Operación
        };
        """
        enums = {}
        # Regex para bloque enum completo
        # enum Nombre { ... };
        block_pattern = re.compile(r"enum\s+(\w+)\s*\{([^}]+)\};", re.DOTALL | re.IGNORECASE)
        
        blocks = block_pattern.findall(self.raw_content)
        
        for enum_name, content in blocks:
            options = []
            # Dividir por comas, ignorando saltos de línea
            # Problema: los comentarios pueden tener comas. Mejor regex por línea o token.
            # Simpler approach: split by comma, but clean comments first? No, comments are key.
            # Split by lines first? No, content can be multi-line.
            # Split by ',' but be careful. Actually MQL5 enums are comma separated.
            # Regex for each item: NAME (= value)? (// comment)?
            
            # Vamos a limpiar comentarios de bloque /* ... */ primero si fuera necesario, pero MQL5 usa //
            
            # Tokenizar por comas, asumiendo que no hay comas en comentarios (riesgoso pero común)
            # Mejor: Iterar sobre el contenido buscando patrones "NOMBRE ... ,"
            
            # Regex para capturar items: 
            # (Identificador) (= Valor)? (,)? (// Comentario)?
            # Modificado para permitir coma opcional antes del comentario
            item_pattern = re.compile(r"([a-zA-Z_]\w*)\s*(?:=\s*[^,/]+)?\s*(?:,\s*)?(?://\s*(.*))?", re.M)
            
            # Limpiar saltos de línea y espacios raros para facilitar
            # content = content.replace("\n", " ") # No, comments need newline detecion or stripping
            
            # Divide y vencerás: Split lines to handle // comments effectively
            lines = content.split('\n')
            clean_content = ""
            for line in lines:
                # Extraer comentario de línea si existe para preservarlo asociado al token
                # Trick: Process line by line.
                # Find valid identifier on line
                match = item_pattern.search(line)
                if match:
                    opt_name = match.group(1)
                    opt_comment = match.group(2) if match.group(2) else opt_name
                    # Save directly
                    options.append({
                        "value": opt_name, # El valor interno es el nombre del enumerador
                        "label": opt_comment.strip() # La etiqueta es el comentario
                    })
            
            if options:
                enums[enum_name] = options
                
        return enums

    def parse_inputs(self) -> List[Dict[str, Any]]:
        extracted_enums = self.parse_enums()
        
        # Regex Robusto para MQL5 Inputs
        pattern = re.compile(r"(input|sinput)\s+([\w:]+)\s+(\w+)\s*=\s*([^;]+);(?:\s*//\s*(.*))?", re.IGNORECASE)
        
        matches = pattern.findall(self.raw_content)
        
        extracted_inputs = []
        
        for match in matches:
            inp_scope, inp_type, inp_name, inp_val_raw, inp_comment = match
            
            value_clean = inp_val_raw.strip()
            label = inp_comment.strip() if inp_comment else inp_name
            
            py_type = "string"
            options = []
            
            # Detectar si es Enum conocido
            if inp_type in extracted_enums:
                py_type = "enum"
                options = extracted_enums[inp_type]
            elif "ENUM_" in inp_type:
                # Enum estándar o no detectado
                py_type = "enum" # Marcar como enum aunque no tengamos opciones (frontend podría usar text input con fallback)
            elif inp_type in ["int", "long", "short", "ulong", "uint"]:
                py_type = "int"
                try: value_clean = int(value_clean)
                except: pass
            elif inp_type in ["double", "float"]:
                py_type = "float"
                try: value_clean = float(value_clean)
                except: pass
            elif inp_type == "bool":
                py_type = "bool"
                if value_clean.lower() == "true": value_clean = True
                elif value_clean.lower() == "false": value_clean = False
            
            extracted_inputs.append({
                "name": inp_name,
                "type": py_type,
                "original_type": inp_type,
                "default": value_clean,
                "label": label,
                "category": "General",
                "options": options # Include options if available
            })
            
        self.inputs = extracted_inputs
        return extracted_inputs

# Prueba Rápida
if __name__ == "__main__":
    # Test con un archivo dummy si existe
    pass
# Prueba Rápida
if __name__ == "__main__":
    # Mockup
    pass
