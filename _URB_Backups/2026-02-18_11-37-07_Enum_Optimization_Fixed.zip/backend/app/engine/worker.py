import multiprocessing
import numpy as np
import polars as pl
import time
from ..core.backtester import FastBacktester
from .memory import SharedMemoryManager, MemoryClient

# Global instance for the worker process
# This avoids pickling the entire dataset for every task
_backtester_instance = None
# We don't need SharedMemoryManager instance in worker, we act as client
_memory_client = None 

def init_worker(shm_name: str, metadata: dict):
    """
    Initializer function for each worker process.
    Connects to Shared Memory and rebuilds the DataFrame pointer.
    """
    global _backtester_instance, _memory_client
    try:
        # 1. Attach to Shared Memory
        _memory_client = MemoryClient(metadata)
        data_dict = _memory_client.get_data()
        
        # 2. Reconstruct DataFrame (Lightweight wrapper)
        # FastBacktester expects a Polars DataFrame
        # We create it from the dict of numpy arrays
        df = pl.DataFrame(data_dict)
        
        # 3. Initialize Numba-Optimized Backtester
        # This will trigger compilation on the first run if not cached
        _backtester_instance = FastBacktester(df)
        
        print(f"[Worker {multiprocessing.current_process().name}] Initialized with {len(df)} rows.")
        
    except Exception as e:
        print(f"[Worker] Init failed: {e}")
        import traceback
        traceback.print_exc()

def run_batch_backtest(strategies: list):
    """
    Runs a batch of strategies against the loaded data.
    strategies: List of dicts (params).
    """
    global _backtester_instance
    results = []
    
    if _backtester_instance is None:
        return [{"error": "Worker not initialized"}] * len(strategies)
        
    for params in strategies:
        try:
            res = _backtester_instance.run(params)
            # Append ID to result to track back
            res['id'] = params.get('id', 'unknown')
            results.append(res)
        except Exception as e:
            results.append({'id': params.get('id'), 'error': str(e), 'NetProfit': -999999})
            
    return results
