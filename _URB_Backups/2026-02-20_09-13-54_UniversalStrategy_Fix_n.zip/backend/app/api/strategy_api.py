from fastapi import APIRouter, File, UploadFile, HTTPException, Body
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import shutil
import os
import re

from ..core.mql5_parser import MQL5Parser
from ..core.state import strat_state
from ..strategies.urb_killzone import URBKillzoneStrategy

router = APIRouter()

# --- Registry ---
# TODO: Scan directory or use proper plugin registry
strategies_registry = {
    "urb_killzone": URBKillzoneStrategy
}

# --- Models ---
class StrategyResponse(BaseModel):
    slug: str
    name: str
    description: str

class SetStrategyRequest(BaseModel):
    slug: str

class StrategyInput(BaseModel):
    name: str
    type: str 
    default: Any
    label: str
    category: str
    options: Optional[List[Dict[str, str]]] = None

class StrategyMetadata(BaseModel):
    filename: str
    inputs: List[StrategyInput]

# --- Endpoints ---

@router.get("/list", response_model=List[StrategyResponse])
def list_strategies():
    """List all available strategies in the factory."""
    results = []
    for slug, cls in strategies_registry.items():
        try:
             inst = cls()
             results.append({
                 "slug": slug,
                 "name": inst.display_name,
                 "description": inst.description
             })
        except Exception as e:
            print(f"Error instantiating {slug}: {e}")
            
    strategies_dir = "backend/strategies_source"
    if os.path.exists(strategies_dir):
        for f in os.listdir(strategies_dir):
            if f.endswith(".mq5"):
                slug = f[:-4]
                results.append({
                    "slug": slug,
                    "name": f"{slug} (MQL5)",
                    "description": "MQL5 Expert Advisor"
                })
                
    return results

@router.post("/set_active")
def set_active_strategy(req: SetStrategyRequest):
    """Set the strategy to be optimized."""
    if req.slug in strategies_registry:
        cls = strategies_registry[req.slug]
        inst = cls()
        
        strat_state.active_name = inst.display_name
        strat_state.active_strategy_slug = req.slug
        # Helper: If get_params_schema is implemented, we could populate active_schema here
        # strat_state.active_schema = inst.get_params_schema()
        
        return {"message": "Strategy Activated", "current": strat_state.active_name}
        
    strategies_dir = "backend/strategies_source"
    file_path = os.path.join(strategies_dir, f"{req.slug}.mq5")
    if os.path.exists(file_path):
        parser = MQL5Parser(file_path)
        if not parser.read_file():
            raise HTTPException(status_code=400, detail="Could not read EA file.")
            
        extracted_inputs = parser.parse_inputs()
        
        inputs_list = []
        for inp in extracted_inputs:
            inputs_list.append(StrategyInput(
                name=inp.get("name"),
                type=inp.get("type"),
                default=inp.get("default"),
                label=inp.get("label", inp.get("name")),
                category=inp.get("category", "General"),
                options=inp.get("options")
            ))
            
        strat_state.active_schema = StrategyMetadata(
            filename=f"{req.slug}.mq5",
            inputs=inputs_list
        )
        strat_state.active_name = req.slug
        strat_state.active_strategy_slug = req.slug
        return {"message": "MQL5 Strategy Activated", "current": strat_state.active_name}

    raise HTTPException(status_code=404, detail="Strategy not found")

@router.post("/import", response_model=StrategyMetadata)
async def import_strategy(file: UploadFile = File(...)):
    """
    Legacy: Upload .mq5 to parse inputs.
    """
    try:
        strategies_dir = "backend/strategies_source"
        if not os.path.exists(strategies_dir):
            os.makedirs(strategies_dir)
        
        file_path = os.path.join(strategies_dir, file.filename)
        
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        parser = MQL5Parser(file_path)
        if not parser.read_file():
            raise HTTPException(status_code=400, detail="Could not read saved file.")
            
        extracted_inputs = parser.parse_inputs()
        
        return {
            "filename": file.filename,
            "inputs": extracted_inputs
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/select")
def select_strategy(strategy: StrategyMetadata):
    """
    Sets the active strategy schema for the Builder to use.
    """
    strat_state.active_schema = strategy
    strat_state.active_name = strategy.filename
    return {"status": "ok", "message": f"Strategy {strategy.filename} selected active."}

class SetFileContent(BaseModel):
    content: str

@router.post("/parse-set")
async def parse_set_file_endpoint(data: SetFileContent):
    """
    Parses content of a .set file and returns structural config.
    """
    try:
        parser = MQL5Parser("")
        parsed_params = parser.parse_set_file(data.content)
        return parsed_params
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
