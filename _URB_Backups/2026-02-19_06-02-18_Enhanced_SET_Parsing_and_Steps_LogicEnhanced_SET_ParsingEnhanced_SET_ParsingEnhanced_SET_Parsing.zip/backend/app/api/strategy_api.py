from fastapi import APIRouter, File, UploadFile, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import shutil
import os
import re

from ..core.mql5_parser import MQL5Parser
from ..core.state import strat_state

router = APIRouter()

# --- Models ---
class StrategyInput(BaseModel):
    name: str
    type: str # 'int', 'double', 'bool', 'string', 'enum'
    default: Any
    label: str
    category: str
    options: Optional[List[Dict[str, str]]] = None

class StrategyMetadata(BaseModel):
    filename: str
    inputs: List[StrategyInput]

# --- Endpoints ---

@router.post("/import", response_model=StrategyMetadata)
async def import_strategy(file: UploadFile = File(...)):
    """
    Sube un archivo .mq5, lo guarda en /strategies y devuelve sus inputs.
    """
    try:
        # Asegurar directorio
        strategies_dir = "backend/strategies_source"
        if not os.path.exists(strategies_dir):
            os.makedirs(strategies_dir)
        
        file_path = os.path.join(strategies_dir, file.filename)
        
        # Guardar archivo
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        # Parsear con MQL5Parser actualizado
        parser = MQL5Parser(file_path)
        if not parser.read_file():
            raise HTTPException(status_code=400, detail="Could not read saved file.")
            
        extracted_inputs = parser.parse_inputs()
        
        return {
            "filename": file.filename,
            "inputs": extracted_inputs
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/select")
def select_strategy(strategy: StrategyMetadata):
    """
    Sets the active strategy schema for the Builder to use.
    """
    strat_state.active_schema = strategy
    strat_state.active_name = strategy.filename
    return {"status": "ok", "message": f"Strategy {strategy.filename} selected active."}

class SetFileContent(BaseModel):
    content: str

@router.post("/parse-set")
async def parse_set_file_endpoint(data: SetFileContent):
    """
    Parses content of a .set file and returns structural config.
    """
    try:
        parser = MQL5Parser("")
        parsed_params = parser.parse_set_file(data.content)
        return parsed_params
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
