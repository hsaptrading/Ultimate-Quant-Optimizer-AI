import React, { useState, useEffect } from 'react';
import axios from 'axios';

const BuilderView = () => {
    const [running, setRunning] = useState(false);
    const [progress, setProgress] = useState(0);
    const [stats, setStats] = useState({ found_count: 0, best_profit: 0, recent_logs: [] });
    const [strategies, setStrategies] = useState([]);

    // Config Form Inputs
    const [config, setConfig] = useState({
        symbol: 'US100',
        population: 100,
        generations: 20
    });

    const [dataReady, setDataReady] = useState(false);
    const fileInputRef = React.useRef(null);
    const [loadedFile, setLoadedFile] = useState(null);

    // Check Data Status on Mount
    useEffect(() => {
        const checkData = async () => {
            try {
                const res = await axios.get('http://127.0.0.1:8000/api/data/status');
                setDataReady(res.data.loaded);
            } catch (e) {
                setDataReady(false);
            }
        };
        checkData();
    }, []);

    // Polling for Status
    useEffect(() => {
        const poll = setInterval(async () => {
            if (!running) return;
            try {
                const res = await axios.get('http://127.0.0.1:8000/api/builder/status');
                const s = res.data;

                // If backend says not running, but frontend thinks it is, sync up
                if (!s.running && running && s.progress === 0 && s.found_count === 0) {
                    // Likely aborted due to error or no data
                    setRunning(false);
                    if (!dataReady) alert("Generation aborted: No Data Loaded!");
                } else {
                    setRunning(s.running);
                    setProgress(s.progress);
                    setStats(s);
                    if (s.found_count > strategies.length) refreshStrategies();
                }
            } catch (e) { console.error(e); }
        }, 1000);
        return () => clearInterval(poll);
    }, [running, strategies.length, dataReady]);

    const refreshStrategies = async () => {
        const res = await axios.get('http://127.0.0.1:8000/api/builder/strategies');
        setStrategies(res.data);
    };

    const handleStart = async () => {
        if (!dataReady) {
            alert("⚠️ Please load Historical Data in 'Configuration' tab first!");
            return;
        }
        try {
            // Include defined params in the configuration payload
            await axios.post('http://127.0.0.1:8000/api/builder/start', { ...config, params: paramState });
            setRunning(true);
            setStrategies([]);
        } catch (e) { alert("Error starting: " + e.message); }
    };

    const handleStop = async () => {
        await axios.post('http://127.0.0.1:8000/api/builder/stop');
        setRunning(false);
    };

    // Load Schema on Mount
    const [strategySchema, setStrategySchema] = useState([]);
    const [paramState, setParamState] = useState({}); // { paramName: { opt: bool, value, start, step, stop } }
    const defaultParamsRef = React.useRef(null); // Store default state for reset
    const [optCriterion, setOptCriterion] = useState('Net Profit');

    useEffect(() => {
        const loadSchema = async () => {
            try {
                const res = await axios.get('http://127.0.0.1:8000/api/config/schema');
                setStrategySchema(res.data);

                // Initialize Param State
                const initial = {};
                res.data.forEach(cat => {
                    cat.params.forEach(p => {
                        initial[p.name] = {
                            opt: false, // Default not optimized
                            value: p.default,
                            start: p.default,
                            step: p.type === 'int' ? 1 : 0.5, // Smart default step
                            stop: p.type === 'int' ? p.default + 5 : p.default + 5.0,
                            steps: 0 // Calc field
                        };
                    });
                });
                setParamState(initial);
                // Save deep copy for reset
                defaultParamsRef.current = JSON.parse(JSON.stringify(initial));
            } catch (e) {
                console.error("Failed to load schema", e);
            }
        };
        loadSchema();
    }, []);

    // Helper to update param state (Refactored to handle Enums)
    // Helper to update param state (Refactored to handle Enums/Bools correctly)
    const updateParam = (p, field, val) => {
        setParamState(prev => {
            const current = prev[p.name];
            // Merge new value first
            let updated = { ...current, [field]: val };

            const isEnum = p.type === 'enum' && p.options?.length > 0;
            const isBool = p.type === 'bool' || p.original_type === 'bool';

            // 1. Enforce Step=1 for Enums/Bools if Optimizing
            if (updated.opt && (isEnum || isBool)) {
                updated.step = 1;
            }

            // 2. Recalculate Steps
            if (updated.opt) {
                if (isEnum) {
                    const startIdx = p.options.findIndex(o => String(o.value) === String(updated.start));
                    const stopIdx = p.options.findIndex(o => String(o.value) === String(updated.stop));
                    // Default to 0 if not found to avoid NaN
                    const s = startIdx === -1 ? 0 : startIdx;
                    const e = stopIdx === -1 ? 0 : stopIdx;

                    // Count discrete items from start to stop
                    const diff = Math.abs(e - s);
                    updated.steps = Math.floor(diff / Math.max(1, updated.step)) + 1;
                }
                else if (isBool) {
                    // Boolean logic (0 or 1)
                    const s = String(updated.start) === 'true' ? 1 : 0;
                    const e = String(updated.stop) === 'true' ? 1 : 0;
                    const diff = Math.abs(e - s);
                    updated.steps = diff + 1; // Step is always 1
                }
                else {
                    // Numeric Logic
                    const step = parseFloat(updated.step) || 1; // Avoid NaN/Zero
                    const diff = Math.abs(updated.stop - updated.start);
                    // Add epsilon (1e-9) to handle floating point errors
                    updated.steps = Math.floor((diff / step) + 1e-9) + 1;
                }
            } else {
                updated.steps = 0;
            }

            return { ...prev, [p.name]: updated };
        });
    };

    const processSetFile = (file) => {
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (event) => {
            try {
                const content = event.target.result;
                const res = await axios.post('http://127.0.0.1:8000/api/strategy/parse-set', { content });
                const parsed = res.data;

                setParamState(prev => {
                    const next = JSON.parse(JSON.stringify(prev));
                    let changed = false;
                    const allParams = strategySchema.flatMap(c => c.params);

                    Object.keys(parsed).forEach(key => {
                        const p = allParams.find(x => x.name === key);
                        if (next[key] && p) {
                            changed = true;
                            // Update fields
                            let newData = { ...parsed[key] };

                            // --- Enum Mapping: Index -> Value ---
                            if (p.type === 'enum' && p.options?.length > 0) {
                                const mapEnum = (val) => {
                                    // If val is integer string "0", "1", map to option value
                                    // If already string, keep it (unlikely from .set)
                                    if (!isNaN(val)) {
                                        const idx = parseInt(val, 10);
                                        if (p.options[idx]) return p.options[idx].value;
                                    }
                                    return val;
                                };
                                if (newData.value !== undefined) newData.value = mapEnum(newData.value);
                                if (newData.start !== undefined) newData.start = mapEnum(newData.start);
                                if (newData.stop !== undefined) newData.stop = mapEnum(newData.stop);
                            }

                            // --- Bool Mapping: 0/1 -> false/true ---
                            if (p.type === 'bool' || p.original_type === 'bool') {
                                const mapBool = (val) => {
                                    const s = String(val).toLowerCase();
                                    if (s === '1' || s === 'true') return true;
                                    if (s === '0' || s === 'false') return false;
                                    return val;
                                };
                                if (newData.value !== undefined) newData.value = mapBool(newData.value);
                                if (newData.start !== undefined) newData.start = mapBool(newData.start);
                                if (newData.stop !== undefined) newData.stop = mapBool(newData.stop);
                            }

                            // Merge Updates
                            Object.assign(next[key], newData);
                            const current = next[key];

                            // Re-Calculate Steps
                            if (current.opt) {
                                const isEnum = p.type === 'enum' && p.options?.length > 0;
                                const isBool = p.type === 'bool' || p.original_type === 'bool';

                                if (isEnum || isBool) current.step = 1;

                                if (isEnum) {
                                    const sIdx = Math.max(0, p.options.findIndex(o => String(o.value) === String(current.start)));
                                    const eIdx = Math.max(0, p.options.findIndex(o => String(o.value) === String(current.stop)));
                                    current.steps = Math.floor(Math.abs(eIdx - sIdx) / Math.max(1, current.step)) + 1;
                                } else if (isBool) {
                                    const s = String(current.start) === 'true' ? 1 : 0;
                                    const e = String(current.stop) === 'true' ? 1 : 0;
                                    current.steps = Math.floor(Math.abs(e - s)) + 1;
                                } else {
                                    // Numeric Logic with Precision Fix
                                    const step = parseFloat(current.step) || 1;
                                    const diff = Math.abs(current.stop - current.start);
                                    // Add epsilon (1e-9) to handle floating point errors (e.g. 1.4/0.1 = 13.999...)
                                    current.steps = Math.floor((diff / step) + 1e-9) + 1;
                                }
                            } else {
                                current.steps = 0;
                            }
                        }
                    });

                    if (changed) {
                        setLoadedFile(file.name);
                    }
                    return next;
                });
            } catch (err) {
                alert("Error loading .SET file: " + err.message);
            }
        };
        reader.readAsText(file);
    };

    const calculateTotalCombinations = () => {
        let total = 1;
        let hasOpt = false;
        Object.values(paramState).forEach(p => {
            if (p.opt && p.steps > 0) {
                total *= p.steps;
                hasOpt = true;
            }
        });
        return hasOpt ? total : 0;
    };

    const formatSteps = (n) => {
        if (n === 0) return "-";
        if (n >= 1e9) return n.toExponential(4);
        return n.toLocaleString();
    };

    const handleSetDrop = (e) => {
        e.preventDefault(); e.stopPropagation();
        processSetFile(e.dataTransfer.files[0]);
    };

    const handleFileSelect = (e) => {
        if (e.target.files && e.target.files[0]) {
            processSetFile(e.target.files[0]);
            e.target.value = null;
        }
    };

    const inputStyle = { padding: '8px', borderRadius: '4px', border: '1px solid #444', background: '#222', color: '#fff', fontSize: '0.9rem' };

    return (
        <div style={{ maxWidth: '1400px', margin: '0 auto', paddingBottom: '100px' }}>
            <div className="header">
                <h1>Strategy Builder</h1>
                <p>Define your optimization landscape and evolve alpha</p>
            </div>

            {/* 1. Optimization Objective */}
            <div className="card">
                <h3>🎯 Optimization Objective</h3>
                <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap' }}>
                    {['Net Profit', 'Profit Factor', 'Expected Payoff', 'Drawdown', 'Recovery Factor', 'Sharpe Ratio', 'Custom', 'Complex Criterion'].map(crit => (
                        <button
                            key={crit}
                            onClick={() => setOptCriterion(crit)}
                            style={{
                                flex: '1 1 150px',
                                padding: '15px',
                                background: optCriterion === crit ? 'rgba(0, 255, 136, 0.15)' : '#222',
                                border: optCriterion === crit ? '1px solid #00ff88' : '1px solid #444',
                                borderRadius: '6px',
                                color: optCriterion === crit ? '#00ff88' : '#888',
                                fontWeight: 'bold',
                                cursor: 'pointer',
                                transition: 'all 0.2s'
                            }}
                        >
                            {optCriterion === crit && "✅ "} {crit}
                        </button>
                    ))}
                </div>
            </div>

            {/* 2. Strategy Configuration */}
            <div className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
                        <h3>⚙️ Strategy Configuration</h3>
                        {calculateTotalCombinations() > 0 && (
                            <div style={{ background: '#111', padding: '5px 10px', borderRadius: '4px', fontSize: '0.85rem', color: '#888', border: '1px solid #333' }}>
                                Total Combinations: <span style={{ color: '#00ff88', fontWeight: 'bold' }}>{formatSteps(calculateTotalCombinations())}</span>
                            </div>
                        )}
                    </div>
                    <input
                        type="file"
                        ref={fileInputRef}
                        style={{ display: 'none' }}
                        accept=".set,.txt"
                        onChange={handleFileSelect}
                    />
                    {loadedFile ? (
                        <div
                            title="Click to clear"
                            onClick={() => {
                                if (window.confirm("Undo/Clear loaded configuration?")) {
                                    setLoadedFile(null);
                                    if (defaultParamsRef.current) {
                                        setParamState(JSON.parse(JSON.stringify(defaultParamsRef.current)));
                                    }
                                }
                            }}
                            style={{ padding: '10px 20px', background: 'rgba(0, 255, 136, 0.15)', border: '1px solid #00ff88', borderRadius: '4px', color: '#00ff88', cursor: 'pointer', fontSize: '0.9rem', display: 'flex', alignItems: 'center', gap: '8px' }}
                        >
                            ✅ Loaded: {loadedFile} <span style={{ fontSize: '0.8em', opacity: 0.7 }}> (Click to Reset)</span>
                        </div>
                    ) : (
                        <div
                            onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                            onDrop={handleSetDrop}
                            onClick={() => fileInputRef.current?.click()}
                            title="Drop .set file or Click to Browse"
                            style={{ padding: '10px 20px', border: '2px dashed #666', borderRadius: '4px', color: '#888', cursor: 'pointer', fontSize: '0.9rem' }}
                        >
                            ☁️ Drag and drop .SET file here (or Click)
                        </div>
                    )}
                </div>

                <div style={{ maxHeight: '600px', overflowY: 'auto' }}>
                    {strategySchema.map(cat => (
                        <div key={cat.category} style={{ marginBottom: '20px' }}>
                            <div style={{ padding: '8px 10px', background: '#333', color: '#fff', fontWeight: 'bold', borderRadius: '4px 4px 0 0', fontSize: '0.85rem' }}>
                                🔹 {cat.category.toUpperCase()}
                            </div>
                            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
                                <thead>
                                    <tr style={{ color: '#666', textAlign: 'left', borderBottom: '1px solid #444' }}>
                                        <th style={{ padding: '10px', width: '40px' }}>Opt</th>
                                        <th style={{ padding: '10px' }}>Parameter</th>
                                        <th style={{ padding: '10px' }}>Value</th>
                                        <th style={{ padding: '10px' }}>Start</th>
                                        <th style={{ padding: '10px' }}>Step</th>
                                        <th style={{ padding: '10px' }}>Stop</th>
                                        <th style={{ padding: '10px', width: '60px' }}>Steps</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {cat.params.map(p => {
                                        const st = paramState[p.name] || {};
                                        const isEnum = p.type === 'enum' && p.options?.length > 0;
                                        const isBool = p.type === 'bool' || p.original_type === 'bool';

                                        return (
                                            <tr key={p.name} style={{ borderBottom: '1px solid #2a2a2a', background: st.opt ? 'rgba(0,255,136,0.02)' : 'transparent' }}>
                                                <td style={{ padding: '10px', textAlign: 'center' }}>
                                                    <input
                                                        type="checkbox"
                                                        checked={st.opt || false}
                                                        onChange={(e) => updateParam(p, 'opt', e.target.checked)}
                                                    />
                                                </td>
                                                {/* Parameter Name */}
                                                <td style={{ padding: '10px', fontWeight: 'bold', color: '#ddd' }}>
                                                    {p.label || p.name}
                                                    {p.label && p.label !== p.name && <div style={{ fontSize: '0.7rem', color: '#666' }}>{p.name}</div>}
                                                </td>

                                                {/* Value (shown if not optimized) */}
                                                <td style={{ padding: '10px' }}>
                                                    {!st.opt ? (
                                                        isEnum ? (
                                                            <select
                                                                value={st.value}
                                                                onChange={(e) => updateParam(p, 'value', e.target.value)}
                                                                style={{ ...inputStyle, width: '100%', cursor: 'pointer' }}
                                                            >
                                                                {p.options.map((opt, idx) => (
                                                                    <option key={idx} value={opt.value}>
                                                                        {opt.label || opt.value}
                                                                    </option>
                                                                ))}
                                                            </select>
                                                        ) : isBool ? (
                                                            <select
                                                                value={st.value}
                                                                onChange={(e) => updateParam(p, 'value', e.target.value === 'true')}
                                                                style={{ ...inputStyle, width: '100%', cursor: 'pointer' }}
                                                            >
                                                                <option value="false">False</option>
                                                                <option value="true">True</option>
                                                            </select>
                                                        ) : (
                                                            <input
                                                                type={p.type === 'int' ? 'number' : 'text'}
                                                                value={st.value}
                                                                onChange={(e) => updateParam(p, 'value', p.type === 'int' ? parseInt(e.target.value) : parseFloat(e.target.value))}
                                                                style={{ ...inputStyle, width: '100%' }}
                                                            />
                                                        )
                                                    ) : <span style={{ color: '#666' }}>-</span>}
                                                </td>

                                                {/* Start (Optimization) */}
                                                <td style={{ padding: '10px' }}>
                                                    {isEnum ? (
                                                        <select
                                                            disabled={!st.opt}
                                                            value={st.start}
                                                            onChange={(e) => updateParam(p, 'start', e.target.value)}
                                                            style={{ ...inputStyle, width: '100%', opacity: st.opt ? 1 : 0.3 }}
                                                        >
                                                            {p.options.map((opt, idx) => (
                                                                <option key={idx} value={opt.value}>{opt.label || opt.value}</option>
                                                            ))}
                                                        </select>
                                                    ) : isBool ? (
                                                        <select
                                                            disabled={!st.opt}
                                                            value={st.start}
                                                            onChange={(e) => updateParam(p, 'start', e.target.value === 'true')}
                                                            style={{ ...inputStyle, width: '100%', opacity: st.opt ? 1 : 0.3 }}
                                                        >
                                                            <option value="false">False</option>
                                                            <option value="true">True</option>
                                                        </select>
                                                    ) : (
                                                        <input
                                                            type="number" disabled={!st.opt}
                                                            value={st.start}
                                                            onChange={(e) => updateParam(p, 'start', parseFloat(e.target.value))}
                                                            style={{ ...inputStyle, width: '100%', opacity: st.opt ? 1 : 0.3 }}
                                                        />
                                                    )}
                                                </td>

                                                {/* Step (Fixed to 1 for Enum/Bool) */}
                                                <td style={{ padding: '10px' }}>
                                                    <input
                                                        type="number"
                                                        disabled={!st.opt || isEnum || isBool}
                                                        value={(isEnum || isBool) ? 1 : st.step}
                                                        onChange={(e) => updateParam(p, 'step', parseFloat(e.target.value))}
                                                        style={{ ...inputStyle, width: '100%', opacity: (st.opt && !isEnum && !isBool) ? 1 : 0.3, background: (isEnum || isBool) ? '#222' : '#111' }}
                                                    />
                                                </td>

                                                {/* Stop (Optimization) */}
                                                <td style={{ padding: '10px' }}>
                                                    {isEnum ? (
                                                        <select
                                                            disabled={!st.opt}
                                                            value={st.stop}
                                                            onChange={(e) => updateParam(p, 'stop', e.target.value)}
                                                            style={{ ...inputStyle, width: '100%', opacity: st.opt ? 1 : 0.3 }}
                                                        >
                                                            {p.options.map((opt, idx) => (
                                                                <option key={idx} value={opt.value}>{opt.label || opt.value}</option>
                                                            ))}
                                                        </select>
                                                    ) : isBool ? (
                                                        <select
                                                            disabled={!st.opt}
                                                            value={st.stop}
                                                            onChange={(e) => updateParam(p, 'stop', e.target.value === 'true')}
                                                            style={{ ...inputStyle, width: '100%', opacity: st.opt ? 1 : 0.3 }}
                                                        >
                                                            <option value="false">False</option>
                                                            <option value="true">True</option>
                                                        </select>
                                                    ) : (
                                                        <input
                                                            type="number" disabled={!st.opt}
                                                            value={st.stop}
                                                            onChange={(e) => updateParam(p, 'stop', parseFloat(e.target.value))}
                                                            style={{ ...inputStyle, width: '100%', opacity: st.opt ? 1 : 0.3 }}
                                                        />
                                                    )}
                                                </td>

                                                <td style={{ padding: '10px', color: '#888', textAlign: 'right' }}>
                                                    {st.opt && st.steps > 0 ? st.steps : ""}
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    ))}
                </div>
            </div>

            {/* 3. Control Panel (Running State) */}
            <div className="card" style={{ position: 'sticky', bottom: '20px', zIndex: 100, border: '1px solid #00ff88', boxShadow: '0 0 20px rgba(0,255,136,0.1)' }}>
                <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>

                    <div style={{ flex: 1 }}>
                        <h4 style={{ margin: 0, color: '#00ff88' }}>{running ? "🚀 Generation in Progress..." : "Ready to Start"}</h4>
                        <div style={{ fontSize: '0.8rem', color: '#888' }}>
                            {running ? `Generation ${stats.recent_logs?.length || 0} / ${config.generations}` : "Configure parameters above and launch optimization."}
                        </div>
                    </div>

                    <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                        <div>
                            <label style={{ fontSize: '0.7rem', color: '#aaa', display: 'block' }}>Population</label>
                            <input type="number"
                                value={config.population}
                                onChange={(e) => setConfig({ ...config, population: parseInt(e.target.value) })}
                                style={{ ...inputStyle, width: '80px', height: '30px' }}
                            />
                        </div>
                        <div>
                            <label style={{ fontSize: '0.7rem', color: '#aaa', display: 'block' }}>Generations</label>
                            <input type="number"
                                value={config.generations}
                                onChange={(e) => setConfig({ ...config, generations: parseInt(e.target.value) })}
                                style={{ ...inputStyle, width: '80px', height: '30px' }}
                            />
                        </div>

                        {!running ? (
                            <button
                                className="primary-btn"
                                onClick={handleStart}
                                style={{ marginLeft: '10px', background: '#00cc88', color: '#000', fontWeight: 'bold' }}
                            >
                                ▶ Start Optimization
                            </button>
                        ) : (
                            <button className="primary-btn" onClick={handleStop} style={{ marginLeft: '10px', background: '#ff4444', color: 'white' }}>
                                🛑 Stop
                            </button>
                        )}
                    </div>
                </div>

                {/* Progress Bar if running */}
                {running && (
                    <div style={{ width: '100%', height: '4px', background: '#333', marginTop: '15px', borderRadius: '2px', overflow: 'hidden' }}>
                        <div style={{ width: `${progress}%`, height: '100%', background: '#00ff88', transition: 'width 0.5s' }}></div>
                    </div>
                )}
            </div>

            {/* Results Preview (Simplified for now - user likely wants specific Results tab later) */}
            <div className="card">
                <h3>🏆 Top Strategies Preview</h3>
                {strategies.length === 0 ? (
                    <p style={{ color: '#666', fontStyle: 'italic' }}>No results yet.</p>
                ) : (
                    <div style={{ display: 'flex', gap: '10px', overflowX: 'auto', paddingBottom: '10px' }}>
                        {strategies.slice(0, 5).map((s, i) => (
                            <div key={i} style={{ minWidth: '200px', background: '#222', padding: '15px', borderRadius: '6px', border: '1px solid #444' }}>
                                <div style={{ color: '#00ff88', fontWeight: 'bold', fontSize: '1.1rem' }}>${s.net_profit.toFixed(2)}</div>
                                <div style={{ fontSize: '0.8rem', color: '#aaa' }}>PF: {s.profit_factor || 0} | WR: {s.win_rate}%</div>
                                <div style={{ fontSize: '0.8rem', color: '#666', marginTop: '5px' }}>ID: {s.id}</div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

// Simple Styles
const inputStyle = {
    padding: '10px',
    background: '#1a1a1a',
    border: '1px solid #333',
    color: 'white',
    borderRadius: 4,
    width: 100
};

const StatBox = ({ label, value, color = 'white' }) => (
    <div style={{ background: '#1a1a1a', padding: 10, borderRadius: 6, textAlign: 'center' }}>
        <div style={{ color: '#666', fontSize: '0.8rem' }}>{label}</div>
        <div style={{ fontSize: '1.2rem', fontWeight: 'bold', color: color }}>{value}</div>
    </div>
);

export default BuilderView;
