
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '.')))

import numpy as np
import polars as pl
from app.core.backtester import FastBacktester
from app.strategies.urb_killzone import URBKillzoneStrategy

def create_dummy_data(n=1000):
    times = np.arange(n) * 60000 + 1600000000000
    opens = np.ones(n) * 1.1000
    closes = np.ones(n) * 1.1005
    highs = np.maximum(opens, closes) + 0.0010
    lows = np.minimum(opens, closes) - 0.0010
    
    # Create a breakout scenario
    # 9:30 - 11:00 is Killzone.
    # We need bars at these times.
    # 9:30 = 9*60 + 30 = 570 min
    # ms_per_day = 86400000
    # Let's align time to start of day
    start_ts = 1600000000000 - (1600000000000 % 86400000)
    times = start_ts + np.arange(n) * 60000 # 1 min bars
    
    # 12:00-16:00 is Range Logic
    # 12:00 = 720 min.
    # Make a High at 13:00 = 1.1050
    # Make a Low at 14:00 = 1.0950
    
    mins = (times % 86400000) // 60000
    
    highs = np.where((mins >= 720) & (mins < 960), 1.1020, highs)
    lows = np.where((mins >= 720) & (mins < 960), 1.0980, lows)
    
    # Breakout at 10:00 (Trading Window 9:30-11:00) next day?
    # Our simple dummy might be just one day.
    
    df = pl.DataFrame({
        'time': times,
        'open': opens,
        'high': highs,
        'low': lows,
        'close': closes,
        'spread_est': np.ones(n) * 1.0
    })
    return df

def test_integration():
    print("Creating Dummy Data...")
    df = create_dummy_data(2000)
    
    print("Initializing Backtester with URBStrategy...")
    bt = FastBacktester(df, strategy_class=URBKillzoneStrategy)
    
    params = {
        'InpTradingStartHour': 9, 'InpTradingStartMin': 0,
        'InpTradingEndHour': 12, 'InpTradingEndMin': 0,
        'InpRangeStartHour': 12, 'InpRangeStartMin': 0,
        'InpRangeEndHour': 16, 'InpRangeEndMin': 0,
        'InpFixedLot': 0.1
    }
    
    print("Running Backtest...")
    res = bt.run(params)
    print("Result:", res)
    
    if 'NetProfit' in res:
        print("SUCCESS: Backtest returned metrics.")
    else:
        print("FAILURE: No metrics returned.")

if __name__ == "__main__":
    test_integration()
