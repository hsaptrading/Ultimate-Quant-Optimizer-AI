import multiprocessing
import numpy as np
import polars as pl
import time
from ..core.backtester import FastBacktester
from .memory import SharedMemoryManager, MemoryClient

# Global instance for the worker process
# This avoids pickling the entire dataset for every task
_backtester_instance = None
# We don't need SharedMemoryManager instance in worker, we act as client
_memory_client = None 

from ..strategies.urb_killzone import URBKillzoneStrategy

def init_worker(shm_name: str, metadata: dict):
    """
    Initializer function for each worker process.
    Connects to Shared Memory and rebuilds the DataFrame pointer.
    """
    global _backtester_instance, _memory_client
    try:
        # 1. Attach to Shared Memory
        _memory_client = MemoryClient(metadata)
        data_dict = _memory_client.get_data()
        
        # 2. Reconstruct DataFrame (Lightweight wrapper)
        df = pl.DataFrame(data_dict)
        
        # 3. Resolve Strategy Class
        # In Phase 2: Use a Registry. For Phase 1: Hardcode Import or Simple Map
        strat_name = metadata.get('active_strategy', 'urb_killzone')
        strategy_class = None
        
        if strat_name == 'urb_killzone':
            strategy_class = URBKillzoneStrategy
        else:
            # Default
            strategy_class = URBKillzoneStrategy

        # 4. Initialize Backtester with Strategy
        _backtester_instance = FastBacktester(df, strategy_class)
        
        print(f"[Worker {multiprocessing.current_process().name}] Initialized with {len(df)} rows. Strategy: {strat_name}")
        
    except Exception as e:
        print(f"[Worker] Init failed: {e}")
        import traceback
        traceback.print_exc()

def run_batch_backtest(strategies: list):
    """
    Runs a batch of strategies against the loaded data.
    strategies: List of dicts (params).
    """
    global _backtester_instance
    results = []
    
    if _backtester_instance is None:
        return [{"error": "Worker not initialized"}] * len(strategies)
        
    for params in strategies:
        try:
            res = _backtester_instance.run(params)
            # Append ID to result to track back
            res['id'] = params.get('id', 'unknown')
            results.append(res)
        except Exception as e:
            results.append({'id': params.get('id'), 'error': str(e), 'NetProfit': -999999})
            
    return results
